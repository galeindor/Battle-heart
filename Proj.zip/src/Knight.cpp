
#include "Knight.h"

Knight::Knight(const sf::Vector2f pos)
	:Player(pos , _knight)
{}
