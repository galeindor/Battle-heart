
#include "Controller.h"

Controller::Controller()
	: m_window(sf::VideoMode(WINDOW_WIDTH, WINDOW_HEIGHT), "Battle Heart")
{
	m_bg.setTexture(*Resources::instance().getBackground(0));
	m_bg.setColor(sf::Color(255, 255, 255, 255));
}

//=======================================================================================
void Controller::run()
{
	float deltaTime = 0.0f;
	auto inProgress = false;

	while (m_window.isOpen())
	{
		drawGame();
		deltaTime = this->m_clock.restart().asSeconds();

		for (auto event = sf::Event{}; m_window.pollEvent(event); )
		{
 			switch (event.type)
			{

			case sf::Event::Closed:
				m_window.close();
				break;
			case sf::Event::MouseButtonPressed:
				auto location = m_window.mapPixelToCoords(
					{ event.mouseButton.x, event.mouseButton.y });

				if (event.mouseButton.button == sf::Mouse::Button::Left)
				{
					inProgress = true;
					handleMouseClick(location);
				}
				break;
			}

		}
		this->update(deltaTime);
		inProgress = false;
	}
}

//=======================================================================================

void Controller::update(float deltaTime)
{
	this->m_board.updateBoard(deltaTime, this->m_charSelected);
}

//=======================================================================================

void Controller::handleMouseClick(sf::Vector2f location)
{
	if (!this->m_charSelected)
		this->m_charSelected = this->m_board.handleFirstClick(location);

	else // if a click made the player move - charSelected is no longer true
		this->m_charSelected = !m_board.handleSecondClick(location);
}


//=======================================================================================

void Controller::drawGame()
{
	m_window.clear(sf::Color::White);
	m_window.draw(m_bg);

	this->m_board.drawBoard(this->m_window, this->m_charSelected);

	m_window.display();
}

//=======================================================================================
/*
void Controller::updatePlayer(int playerIndex , sf::Vector2f dest)
{
	sf::Clock clock;

	auto direction = dest - m_players[playerIndex]->getPosition();

	if (m_players[playerIndex]->moveValidator())
	{
		auto delta = clock.restart().asSeconds();
		m_players[playerIndex]->movePlayer(direction, delta);
	}
}
*/
//=======================================================================================