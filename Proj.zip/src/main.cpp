#include "Controller.h"

int main()
{
	auto game = Controller();
	game.run();
}
